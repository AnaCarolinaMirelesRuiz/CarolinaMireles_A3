/* Calculadora Primos */
#include <stdio.h>
int numprimo(int num);

int numprimo(int num) {
  if (num == 0 || num == 1) return 0;
  if (num == 4) return 0;
  for (int x = 2; x < num / 2; x++) {
    if (num % x == 0) return 0;
  }
  return 1;
}

int main(void) {
  int num;
  printf("Ingresa un número: \n");
  scanf("%d", &num);
  if (numprimo(num)) {
    printf("Es primo.");
  } else {
    printf("No es primo.");
  }
  return 0;
}