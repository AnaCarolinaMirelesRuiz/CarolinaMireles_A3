/* Calculadora Par/Impar */
#include <stdio.h>
int main() 

{
    
int n1, n2, n3, n4, n5, n6, n7, n8, n9, n10;
printf("Ingrese el primer número: \n");
scanf("%d", &n1);
printf("Ingrese el segundo número: \n");
scanf("%d", &n2);
printf("Ingrese el tercer número: \n");
scanf("%d", &n3);
printf("Ingrese el cuarto número: \n");
scanf("%d", &n4);
printf("Ingrese el quinto número: \n");
scanf("%d", &n5);
printf("Ingrese el sexto número: \n");
scanf("%d", &n6);
printf("Ingrese el séptimo número: \n");
scanf("%d", &n7);
printf("Ingrese el octavo número: \n");
scanf("%d", &n8);
printf("Ingrese el noveno número: \n");
scanf("%d", &n9);
printf("Ingrese el décimo número: \n");
scanf("%d", &n10);

if (n1%2==0)
{
printf("\n\nEl primer número es par.\n\n");
}
else
{
printf("\n\nEl primer número es impar.\n\n");
}

/*Segundo numero*/

if (n2%2==0)
{
printf("El segundo número es par.\n\n");
}
else
{
printf("El segundo número es impar.\n\n");
}

/*Tercer numero*/

if (n3%2==0)
{
printf("El tercer número es par.\n\n");
}
else
{
printf("El tercer número es impar.\n\n");
}

/*Cuarto numero*/

if (n4%2==0)
{
printf("El cuarto número es par.\n\n");
}
else
{
printf("El cuarto número es impar.\n\n");
}

/*Quinto numero*/

if (n5%2==0)
{
printf("El quinto número es par.\n\n");
}
else
{
printf("El quinto número es impar.\n\n");
}

/*Sexto numero*/
if (n6%2==0)
{
printf("El sexto número es par.\n\n");
}
else
{
printf("El sexto número es impar.\n\n");
}

/*Septimo numero*/
if (n7%2==0)
{
printf("El séptimo número es par.\n\n");
}
else
{
printf("El séptimo número es impar.\n\n");
}

/*Octavo numero*/
if (n8%2==0)
{
printf("El octavo número es par.\n\n");
}
else
{
printf("El octavo número es impar.\n\n");
}

/*Noveno numero*/
if (n9%2==0)
{
printf("El noveno número es par.\n\n");
}
else
{
printf("El noveno número es impar.\n\n");
}

/*Decimo numero*/
if (n10%2==0)
{
printf("El décimo número es par.\n\n");
}
else
{
printf("El décimo número es impar.\n\n");
}

return 0;
}