/* Calculadora Al Revés */
#include <stdio.h>
int main(void){

int num, resto, inv=0;                               
printf("Ingrese un numero: \n");
scanf("%d",&num);
while(num!=0)                               
{
resto=num%10;
num=num/10;         
inv=inv*10+resto;         
}
printf("\nEl número invertido es:\n");
printf("%d \n",inv);
return 0;
}